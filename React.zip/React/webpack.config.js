
const webpackConfig = require("./webpackconfig")
console.log("Reached webpack.config");
module.exports = () => {
	const loadedInstance = new webpackConfig();

	process.env.NODE_ENV = loadedInstance.env;
	console.log("Called webpack.config");
	return loadedInstance.config;
}