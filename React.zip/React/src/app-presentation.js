import React from "react";
import FormBuilder from "./formBuilder/component/FormBuilderScreenComponent";


export default class App extends React.Component {
	constructor(props) {
		super(props);
	}

	componentDidMount() {
		document.title = "Form Ajmal Builder";
	}

	render() {
		return (
			<FormBuilder />
			);
	}
};