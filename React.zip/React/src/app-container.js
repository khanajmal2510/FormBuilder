import { connect } from "react-redux";
import App from "./app-presentation";

const mapStateToProps = (state) => {
	return {
		data: state.formBuilder.data
	};
};

const mapDispatchToProps = (dispatch) => {
	return {
	};
};

export default connect(mapStateToProps, mapDispatchToProps)(App);