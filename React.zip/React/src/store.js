import { createStore } from "redux";

import createReducer from "./reducer"

const initializeStore = () => {

	const store = createStore(
		createReducer
	);

	return store;

};

const store = initializeStore();

export default store;