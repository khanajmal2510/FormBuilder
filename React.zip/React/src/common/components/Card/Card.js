import React from "react";

import styles  from "./Card.scss"

const Card = (props) => {

    const cardOutlineClassNames = [];
    cardOutlineClassNames.push(styles["ut-card__outline"]);

    const cardClassNames = [];
    cardClassNames.push(styles["ut-card"]);

	return (
        <div className={cardOutlineClassNames.join(" ")}>
            {props.title && (
                <span className={styles["ut-card__title"]}>
                    <span>{props.title}</span>
                </span>
            )}
            <div className={cardClassNames.join(" ")}>{props.children}</div>
        </div>
	);
};

export default Card;