import React, { useMemo } from "react";
import PropTypes from "prop-types";

const TextBox = (props) => {
	return (

		<input style={{ width: "100%"}}
			type={props.type}
			name={props.name}
			value={props.value}
			onChange={props.onChange}
		/>
	);
};

TextBox.propTypes = {
	name: PropTypes.string.isRequired,
	value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
	type: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired
};


export default TextBox;