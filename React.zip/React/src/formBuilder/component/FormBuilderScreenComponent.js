import React, { useState, useMemo } from "react";

import { COMPONENT_FIELD, FORMBUILDER_TEMPLATES } from "../formBuilderUtil";

import TextFieldBuilder from "./fields/TextFieldBuilder";
import RadioFieldBuilder from "./fields/RadioFieldBuilder";
import StaticFieldBuilder from "./fields/StaticFieldBuilder";
import styles from "./FormBuilderScreenComponent.scss";

let header = <h1>Welcome to Form Builder</h1>;

const formBuilder = (props) => {

	const [form, setForm] = useState(new Map());

	const onChange = (id, value) => {
		let formData = new Map(form);
		let fieldData = { ...formData.get(id) };
		fieldData.value = value;
		formData.set(id, fieldData);

		setForm(formData);
	};

	function renderForm() {
		let result = [];
		form.forEach((value, key) => {
			switch (value.type) {
				case COMPONENT_FIELD.TEXT:
					result.push(<div className={styles["formBuilder__field"]} key={key}>
						<TextFieldBuilder
							{...value}
							id={key}
							onChange={onChange}
						/>
					</div>);
					break;

				case COMPONENT_FIELD.RADIO:
					result.push(<div className={styles["formBuilder__field"]} key={key}>
						<RadioFieldBuilder
							{...value}
							id={key}
							onChange={onChange}
						/>
					</div>);
					break;

				case COMPONENT_FIELD.STATIC:
					result.push(<div className={styles["formBuilder__field"]} key={key}>
						<StaticFieldBuilder
							{...value}
							id={key}
							onChange={onChange}
						/>
					</div>);
					break;
			}

		});

		return result;
	}

	const onClick = (type) => {
		let formData = new Map(form);
		formData.set(formData.size, FORMBUILDER_TEMPLATES.get(type));
		setForm(formData);
	};


	let className = [];
	className.push(styles["formBuilder"]);

	console.log(form);
	return (
		<div className={className.join(" ")}>
			{header}
			{useMemo(renderForm, [form])}

			<span onClick={() => onClick(COMPONENT_FIELD.TEXT)} key={COMPONENT_FIELD.TEXT} >Add Text</span>
			<span onClick={() => onClick(COMPONENT_FIELD.RADIO)} key={COMPONENT_FIELD.RADIO} >Add Radio</span>
			<span onClick={() => onClick(COMPONENT_FIELD.STATIC)} key={COMPONENT_FIELD.STATIC}>Add Static</span>

		</div>);
};


export default formBuilder;