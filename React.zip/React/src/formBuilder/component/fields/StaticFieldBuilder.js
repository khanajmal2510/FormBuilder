import React, { useMemo } from "react";
import PropTypes from "prop-types";

import TextBox from "../../../common/components/TextBox";
import Card from "../../../common/components/Card/Card";

//import styles from "./StaticFieldBuilder.scss";


const StaticFieldBuilder = (props) => {

	const onChange = (e) => {
		let value = { ...props.value };
		value[e.target.name] = e.target.value;

		props.onChange(props.id, value);
	};


	return (
		<Card title={props.displayName}>
			<TextBox
				type="text"
				name="text"
				value={props.value.text}
				onChange={onChange}
			/>
		</Card >
	);
};


StaticFieldBuilder.propTypes = {
	displayName: PropTypes.string.isRequired,
	id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
	value: PropTypes.shape({
		text: PropTypes.string.isRequired,
	}).isRequired,
	onChange: PropTypes.func.isRequired
};


export default StaticFieldBuilder;