import React, { useMemo, useState } from "react";
import PropTypes from "prop-types";

import TextBox from "../../../common/components/TextBox";
import Card from "../../../common/components/Card/Card";

import styles from "./RadioFieldBuilder.scss";


const RadioFieldBuilder = (props) => {

	const [newOption, setNewOption] = useState("");

	const onChange = (e) => {
		let value = { ...props.value };
		value[e.target.name] = e.target.value;

		props.onChange(props.id, value);
	};

	const onAddableOptionChange = (e) => {
		setNewOption(e.target.value);
	};

	const onAdd = () => {
		let value = { ...props.value };
		let options = [...value.options];
		options.push(newOption);
		setNewOption("");

		value.options = options;
		props.onChange(props.id, value);
	}

	const remove = (index) => {
		let value = { ...props.value };
		let options = [...value.options];

		if (index > -1) {
			options.splice(index, 1);
		}

		value.options = options;
		props.onChange(props.id, value);
	}

	let radioOptions = useMemo(() => {
		let result = props.value.options.map((x, index) => {
			return <li key={index} onClick={() => remove(index)} >{x}</li>
		});

		return result;
	}, [props.value.options]);


	return (
		<Card title={props.displayName}>
			<div>
				<div className={styles["RadioFieldBuilder__section"]}>
					<TextBox
						type="text"
						name="text"
						value={props.value.text}
						onChange={onChange}
					/>
				</div>
				<div className={styles["RadioFieldBuilder__section"]}>
					<div>{radioOptions}</div>
					<TextBox
						type="text"
						name="addableOption"
						value={newOption}
						onChange={onAddableOptionChange}
					/>
					< span onClick={onAdd}>Add</span>
				</div>
			</div>
		</Card>
	);
};


RadioFieldBuilder.propTypes = {
	displayName: PropTypes.string.isRequired,
	id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
	value: PropTypes.shape({
		text: PropTypes.string.isRequired,
		options: PropTypes.array,
	}).isRequired,
	onChange: PropTypes.func.isRequired
};


export default RadioFieldBuilder;