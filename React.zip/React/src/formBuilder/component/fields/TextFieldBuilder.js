import React, { useMemo } from "react";
import PropTypes from "prop-types";

import TextBox from "../../../common/components/TextBox";
import Card from "../../../common/components/Card/Card";

import styles from "./TextFieldBuilder.scss";


const TextFieldBuilder = (props) => {

	const onChange = (e) => {
		let value = { ...props.value };
		value[e.target.name] = e.target.value;

		props.onChange(props.id, value);
	};


	return (
		<Card title ={props.displayName}>
			<div>
				<div className={styles["TextFieldBuilder__section"]}>
					<TextBox
						type="text"
						name="text"
						value={props.value.text}
						onChange={onChange}
					/>
				</div>
				<div className={styles["TextFieldBuilder__section"]}>
					<span>Allowed Characters </span>
					<span className={styles["TextFieldBuilder__section__right"]}>
						<TextBox
							type="number"
							name="maxLength"
							value={props.value.maxLength}
							onChange={onChange}
						/>
					</span>
				</div>
			</div>
		</Card>
	);
};


TextFieldBuilder.propTypes = {
	displayName: PropTypes.string.isRequired,
	id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
	value: PropTypes.shape({
		text: PropTypes.string.isRequired,
		maxLength: PropTypes.number,
	}).isRequired,
	onChange: PropTypes.func.isRequired
};


export default TextFieldBuilder;