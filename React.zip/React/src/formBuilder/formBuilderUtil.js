export const COMPONENT_FIELD = {
	STATIC: 1,
	RADIO: 2,
	TEXT: 3
};

const staticTemplate = () => {
	return {
		displayName: "Static",
		type: COMPONENT_FIELD.STATIC,
		value: {
			text: "Example of the form builder in action."
		}
	};
};

const radioTemplate = () => {
	return {
		displayName: "Radio",
		type: COMPONENT_FIELD.RADIO,
		value: {
			text: "What is the colour?",
			options: []
		}
	};
};

const textTemplate = () => {
	return {
		displayName: "Text",
		value: {
			text: "What is your name?",
			maxLength: 500
		},
		type: COMPONENT_FIELD.TEXT,
	};
};

let templates = new Map();
templates.set(COMPONENT_FIELD.STATIC, staticTemplate());
templates.set(COMPONENT_FIELD.RADIO, radioTemplate());
templates.set(COMPONENT_FIELD.TEXT, textTemplate());


export const FORMBUILDER_TEMPLATES = templates;