
const createReducer = () => {
	return {
		formBuilder: {
			data: "123456"
		}
	};
};


export default createReducer;