const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const AsyncChunkNames = require("webpack-async-chunk-names-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const ScriptExtHtmlWebpackPlugin = require("script-ext-html-webpack-plugin");


const DIST_DIR = path.resolve(__dirname, "./dist");
const SRC_DIR = path.resolve(__dirname, "./src");
const PUBLIC_PATH = "/"

class WebPackConfig {
	constructor() {
		this._config = {
			watch: true,
			entry: {
				main: SRC_DIR + "/index.js",
			},
			output: {
				path: DIST_DIR + "/",
				filename: "[name].[contenthash].js",
				chunkFilename: "[name].[contenthash].js",
				publicPath: PUBLIC_PATH,
			},
			module: {
				rules: [
					{
						test: /\.(js|jsx)$/,
						exclude: /(node_modules|bower_components)/,
						use: {
							loader: "babel-loader",
							options: {
								presets: ["@babel/preset-env", "@babel/preset-react"]
							},
						},
					},
					{
						//test: /\.scss$/,
						test: /\.(sa|sc|c)ss$/,
						use: [
							MiniCssExtractPlugin.loader,
							{
								loader: "css-loader",
								options: {
									modules: true,
									sourceMap: true,
									localIdentName: "[name]__[local]___[hash:base64:5]",
								},
							},
							{
								loader: "sass-loader",
								options: {
									modules: true,
									sourceMap: true,
								},
							},
						],
					}
				],
			},
			plugins: [
				new MiniCssExtractPlugin({
					// Options similar to the same options in webpackOptions.output
					// both options are optional
					filename: "[name].[contenthash].css",
					chunkFilename: "[name].[contenthash].css",
				}),
				new AsyncChunkNames(),
				new HtmlWebpackPlugin({
					inject: true,
					hash: false,
					title: "Business",
					template: SRC_DIR + "/index.html",
					filename: "index.html",
					publicPath: PUBLIC_PATH,
					meta: {
						viewport:
							"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no",
						"msapplication-square150x150logo":
							"/app/assets/images/favicon-new/150x150.png",
						"msapplication-TileImage":
							"/app/assets/images/favicon-new/150x150.png",
						"msapplication-TileColor": "#008ed6",
						"application-name": "Musafir.Com",
						"apple-mobile-web-app-capable": "yes",
						"theme-color": "#004499",
						"msapplication-navbutton-color": "#004499",
						"apple-mobile-web-app-status-bar-style": "#004499",
						manifest: "/manifest.json",
					},
				}),
				new ScriptExtHtmlWebpackPlugin({
					defaultAttribute: "defer",
				}),
			],
		};
	}

	set config(data) {
		this._config = { ...this.defaultSettings, ...data };
		return this._config;
	}

    /**
     * Get the global config
     * @return {Object} config Final webpack config
     */
	get config() {
		return this._config;
	}


	get env() {
		return "dev";
	}
}
module.exports = WebPackConfig