var rimraf = require("rimraf");
rimraf(
    "dist/*",
    {
        glob: {
            ignore: ["dist/config.js", "dist/bundle-stats.html"],
        },
    },
    () => { },
);
